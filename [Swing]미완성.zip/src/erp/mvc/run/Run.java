package erp.mvc.run;

import erp.mvc.view.Login_Main_View;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login_Main_View();
	}

}
