package erp.mvc.ex;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Test_dataParser {
    public static void main(String[] args) throws Exception{
        while(true) {
            String target = "https://www.naver.com/"; 
            HttpURLConnection con = (HttpURLConnection) new URL(target).openConnection(); 
            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            String temp;
            StringBuffer info = new StringBuffer();
            FileWriter fw = null;
            int rank = 0;

            while ((temp = br.readLine()) != null) {
                if (temp.contains("var svt = \"")) {
                    String pathName = temp.split("= \"")[1].split("\";")[0] + ".txt";
                    fw = new FileWriter(pathName);
                    fw.write(info.toString());
                    fw.close();
                }
                if (temp.contains("ah_k") && rank < 20) {
                    info.append("현재 순위 " + ++rank + "위 : " + temp.split("<span class=\"ah_k\">")[1].split("</span>")[0] + "\r\n");
                }
            }
            con.disconnect();
            br.close();
            Thread.sleep(10000);
        }
    
}
}	//naver.com 소스 정보 갖고오기                             웹파싱이란 자신이 원하는 HTML 문서의 데이터를 뽑아서 원하는 형태로 취하는 것이다.}
