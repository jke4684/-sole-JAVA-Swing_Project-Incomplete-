package erp.mvc.ex;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import javax.swing.tree.*;

class Exam02_sub extends JFrame implements TreeExpansionListener , TreeSelectionListener
,TreeModelListener{
	private Container con;
	private DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
	private DefaultTreeModel dtm = new DefaultTreeModel(root);
	private JTree jt = new JTree(dtm);
	private JScrollPane jsp = new JScrollPane(jt);
	
	
	private DefaultMutableTreeNode node = new DefaultMutableTreeNode("1 node");
	private DefaultMutableTreeNode node_1 = new DefaultMutableTreeNode("Root1");
	private DefaultMutableTreeNode node_2 = new DefaultMutableTreeNode("Roo2t");
	private DefaultMutableTreeNode node_3 = new DefaultMutableTreeNode("Root3");
	private DefaultMutableTreeNode node_4 = new DefaultMutableTreeNode("Root4");
	private DefaultMutableTreeNode node1 = new DefaultMutableTreeNode("2 node");
	private DefaultMutableTreeNode node_1_1 = new DefaultMutableTreeNode("Root1");
	private DefaultMutableTreeNode node_1_2 = new DefaultMutableTreeNode("Root2");
	private DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("3 node");
	private DefaultMutableTreeNode node_2_1 = new DefaultMutableTreeNode("Root1");
	private DefaultMutableTreeNode node_2_2 = new DefaultMutableTreeNode("Root2");

	
	public Exam02_sub(){
		super("TEST");
		this.init();
		this.start();
		this.setSize(300,300);
		this.setVisible(true);
		
		try{
			Thread.sleep(2000);
		}catch(InterruptedException ee){}
		root.remove(node);
		dtm.reload(); // 변화 적용 
	}
	
	public void init(){
		con = this.getContentPane();
		con.setLayout(new BorderLayout(5,5));
		con.add("North",new JLabel(" **  JTREE EVENT ** ",JLabel.CENTER));
		con.add("South",new JButton("확인"));
		root.add(node); root.add(node1); root.add(node2);
		node.add(node_1);node.add(node_2);node.add(node_3);node.add(node_4);
		node1.add(node_1_1);node1.add(node_1_2);
		node2.add(node_1_1);node2.add(node_1_2);
		
		con.add("Center",jsp);
	}
	public void start(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jt.addTreeExpansionListener(this);
		jt.addTreeSelectionListener(this);
		dtm.addTreeModelListener(this);
	}
	public void treeCollapsed(TreeExpansionEvent e){
		System.out.println("접혔당....: " + e.getPath());
	} 
	public void treeExpanded(TreeExpansionEvent e){
		System.out.println("열렸당....: " + e.getPath());
	} 
	public void valueChanged(TreeSelectionEvent e){
		System.out.println("현재 선택한 폴더 ....: " + e.getPath());
		
		
		// 선택되었을때 getPath() 노드의 이름을 가져옴. 
		// DB 노드 이름 들어가면 조건문해서 패널 출력 
	}
	
	public void treeNodesChanged(TreeModelEvent e){
		System.out.println("노드의 글자가 바뀌었당 " );
	}  
	public void treeNodesInserted(TreeModelEvent e){

	}  
	public void treeNodesRemoved(TreeModelEvent e){}
	public void treeStructureChanged(TreeModelEvent e){
		System.out.println(" 트리의 구조가 변함  " );
	} 
}

public class Test_Exam02 {
	
	public static void main(String[] ar){
		try{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception ee){}
		Exam02_sub es = new Exam02_sub();
	}
}