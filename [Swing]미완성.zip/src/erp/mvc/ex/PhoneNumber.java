package erp.mvc.ex;

import java.util.Random;
import java.util.Scanner;

public class PhoneNumber {
	@SuppressWarnings("static-access")
	public static void main(String[] arg) { 
		int data;
		String test ="010-9999-9999";
		Scanner sc = new Scanner(System.in);
		
		//13자리만 받게 작업. 
		
		//011 , 010, 016, 017, 018, 019
		System.out.println(test.substring(0,3));
		if(test.substring(0,3).equals("011")&&test.substring(0,3).equals("010")
				&&test.substring(0,3).equals("016")&&test.substring(0,3).equals("017")
				&&test.substring(0,3).equals("018")&&test.substring(0,3).equals("019")) {
			System.out.println("반가워요 ");
		}else
		{
			System.out.println("틀린번호 입니다. 다시입력해주세요 ");
		}
		//인증 번호 
		data = new Random().nextInt(999900)+100000;
		System.out.println(data);
		
		}
}
