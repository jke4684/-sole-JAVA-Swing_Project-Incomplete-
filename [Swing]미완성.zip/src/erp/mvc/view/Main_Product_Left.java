package erp.mvc.view;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import erp.mvc.controller.Join_controller;

public class Main_Product_Left implements TreeExpansionListener , TreeSelectionListener
,TreeModelListener{
	private Join_controller jc = new Join_controller();
	private Windows_Gui_Home wg = new Windows_Gui_Home();
	private JPanel product_Left = wg.JPanelAdd(30, 227, 262, 583);	
	private DefaultMutableTreeNode root = new DefaultMutableTreeNode("포토폴리오List");
	private DefaultTreeModel defult_Tree = new DefaultTreeModel(root);
	private DefaultMutableTreeNode child1 = new DefaultMutableTreeNode("개      요");
	private DefaultMutableTreeNode child2 = new DefaultMutableTreeNode("교      육");
	private DefaultMutableTreeNode child3 = new DefaultMutableTreeNode("프로젝트");
	private DefaultMutableTreeNode child1_child1 = new DefaultMutableTreeNode("1.1.이력서");

	private DefaultMutableTreeNode child2_child1 = new DefaultMutableTreeNode("2.1.대학교에서 배운 내용");

	private DefaultMutableTreeNode child3_child1 = new DefaultMutableTreeNode("3.1.JDBC 구현 프로젝트");
	private DefaultMutableTreeNode child3_child2 = new DefaultMutableTreeNode("3.2.정적페이지 구현 프로젝트");
	private DefaultMutableTreeNode child3_child3 = new DefaultMutableTreeNode("3.3.재감염 방지 프로젝트");
	private DefaultMutableTreeNode child3_child4 = new DefaultMutableTreeNode("3.4.아두이노를 활용한 프로젝트");
	private DefaultMutableTreeNode child3_child5 = new DefaultMutableTreeNode("3.5.웹사이트 관련 프로젝트");
	private JTree myTree = new JTree(defult_Tree);
	public Main_Product_Left(JFrame view, JLabel product) {

		
//		  jt.addSelectionRow(1); //특정 행을 선택할 수 있도록 설정한다.배열처럼 0부터 시작한다.
//		  jt.expandRow(1); //만약 하위의 트리를 가진다면 확장이 되어 표현된다.
//		  jt.setDragEnabled(true); //각 노드들에 대한 Drag속성을 활성 상태로 변경한다.
//		  jt.setEditable(true);  //각 노드들에 대한 수정 권한을 준다.
//		  jt.setToggleClickCount(2); //Toggle지정 시 클릭 수
		myTree.expandRow(0);// 하위 트리 가진다면 확장되어 표현
		root.add(child1);
		root.add(child2);
		root.add(child3);
		child1.add(child1_child1);

		child2.add(child2_child1);

		child3.add(child3_child1);
		child3.add(child3_child2);
		child3.add(child3_child3);
		child3.add(child3_child4);
		child3.add(child3_child5);

		product_Left.setLayout(new BorderLayout());
		product_Left.setBackground(new Color(0, 0, 0, 0));
		product_Left.add(myTree);
		product.add(product_Left);
		// 1190, 579 Home View 크기.
		myTree.addTreeExpansionListener(this);
		myTree.addTreeSelectionListener(this);
		defult_Tree.addTreeModelListener(this);
		
		
	}
	@Override
	public void treeCollapsed(TreeExpansionEvent e){
//		System.out.println("접혔당....: " + e.getPath());
	} 
	@Override
	public void treeExpanded(TreeExpansionEvent e){
//		System.out.println("열렸당....: " + e.getPath());
	} 
	@Override
	public void valueChanged(TreeSelectionEvent e){
		String tree_Select_Path = e.getPath().toString();
		System.out.println("현재 선택한 폴더 ....: " + tree_Select_Path);
//		jc.resume(tree_Select_Path);
		
		
		// 선택되었을때 getPath() 노드의 이름을 가져옴. 
		// DB 노드 이름 들어가면 조건문해서 패널 출력 
	}
	@Override
	public void treeNodesChanged(TreeModelEvent e){
		System.out.println("노드의 글자가 바뀌었당 " );
		
	}  
	@Override
	public void treeNodesInserted(TreeModelEvent e){
		
	}  
	@Override
	public void treeNodesRemoved(TreeModelEvent e){
		
	}
	@Override
	public void treeStructureChanged(TreeModelEvent e){
		System.out.println(" 트리의 구조가 변함  " );
	}
	
	
	
}
