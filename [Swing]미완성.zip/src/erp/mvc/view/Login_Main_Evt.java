package erp.mvc.view;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import erp.mvc.controller.Join_controller;
import erp.mvc.controller.MyCustomJButton;

public class Login_Main_Evt {
	private Join_controller jc = new Join_controller();
	private Windows_Gui_Home wg = new Windows_Gui_Home();

	public void login_join() {
		JDialog login_join_View = wg.JDialogAdd(300, 300, 470, 690);
		Image icon = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB_PRE);
		JPanel back = wg.JPanelAdd(0, 0, 470, 690);
		JLabel background_J = new JLabel(wg.ImageIcon("./img/join_Background.png"));
		JTextField j_Input_Name = new JTextField(); //이름 
		JTextField j_Input_Number = new JTextField(); // 주민등록번ㄴ호
		JTextField j_Input_phone = new JTextField(); // 연락처 
		JTextField j_Input_P_S = new JTextField(); // 인증 키 
		JTextField j_Input_Id = new JTextField(); // 아이디 
		JTextField j_Input_Pwd = new JTextField(); // 비밀번호 
		JTextField j_Input_Adress = new JTextField(); // 주소 
		JTextField j_Input_A_D = new JTextField(); // 상세주소 
		JTextField j_Input_Mail = new JTextField();  // 이메일 
		JTextField j_Input_M_D = new JTextField(); /// 인증 
		MyCustomJButton j_Btn_Ok = new MyCustomJButton(); // 확인 
		MyCustomJButton j_Btn_No = new MyCustomJButton(); // 취소 
		MyCustomJButton j_Btn_C_N = new MyCustomJButton(); // 주민등록번호 
		MyCustomJButton j_Btn_C_P = new MyCustomJButton(); // 연락처 인증 버튼 
		MyCustomJButton j_Btn_C_A = new MyCustomJButton(); // 주소 도로교통공사 버튼
		MyCustomJButton j_Btn_C_E = new MyCustomJButton(); // 이메일 전송 버튼
		
		j_Btn_Ok.setBounds(82,583,115,46);
		j_Btn_Ok.setBackground(Color.red);
		j_Btn_Ok.setForeground(Color.white);
//		j_Btn_C_P.setBounds(r);
//		j_Btn_C_A.setBounds(r);
//		j_Btn_C_E.setBounds(r);
//		j_Btn_C_N.setBounds(r);
		
		j_Btn_Ok.setText("확인");
		
		
		j_Btn_No.setBounds(258,583,115,46);
		j_Btn_No.setBackground(Color.red);
		j_Btn_No.setForeground(Color.white);
		j_Btn_No.setText("취소");
		
		login_join_View.setIconImage(icon);
		j_Input_Name.setBounds(119,115,262,34); // 이름 
		j_Input_Number.setBounds(120,162,204,34); // 주민등록번호 
		j_Btn_C_N.setBounds(320,162,60,34);
		j_Btn_C_N.setText("인증");

		j_Input_phone.setBounds(120,208,204,34);// 폰넘버
		j_Btn_C_P.setBounds(320,208,60,34);
		j_Btn_C_P.setText("인증");
		
		j_Input_P_S.setBounds(120,256,129,34); 
		j_Input_Id.setBounds(120,298,262,34);
		// 230
		j_Input_Pwd.setBounds(120,345,262,34);
		j_Input_Adress.setBounds(120,392,204,34);
		j_Btn_C_A.setBounds(320,392,60,34);
		j_Btn_C_A.setText("인증");
		j_Input_A_D.setBounds(120,438,262,34);
		j_Input_Mail.setBounds(120,486,204,34);
		j_Btn_C_E.setBounds(320,486,60,34);
		j_Btn_C_E.setText("인증");
		j_Input_M_D.setBounds(120,528,204,34);
		// 160 연락
		background_J.setBounds(-10, -40, 470, 730);
		
		back.add(j_Btn_C_P);
		back.add(j_Btn_C_A);
		back.add(j_Btn_C_E);
		back.add(j_Btn_C_N);
		back.add(j_Btn_No);
		back.add(j_Btn_Ok);
		back.add(background_J);
		back.add(j_Input_Name);
		back.add(j_Input_Number);
		back.add(j_Input_phone);
		back.add(j_Input_P_S);
		back.add(j_Input_Id);
		back.add(j_Input_Adress);
		back.add(j_Input_Pwd);
		back.add(j_Input_Mail);
		back.add(j_Input_M_D);
		back.add(j_Input_A_D);
		login_join_View.add(back);
		login_join_View.setVisible(true);
		// 이 름 :
		// 생 년 월 일 : 주민등록번호 API
		// 연 락 처 : 핸드폰 인증 API
		// 아 이 디 :
		// 비 밀 번 호 :
		// 비밀번호 확인 :
		// 주 소 : 주소지 API
		// 이 메 일 주 소 : 이메일 체크 API
		// 닉 네 임 :
		// 성 별 :
		j_Btn_Ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String j_Name = j_Input_Name.getText();
				String j_Index = j_Input_Number.getText();
				String j_Phone = j_Input_phone.getText();
				String j_Id = j_Input_Id.getText();
				String j_Pwd = j_Input_Pwd.getText();
				String j_Ads = j_Input_Adress.getText()+j_Input_A_D.getText();
				String j_Mail = j_Input_Mail.getText();
				
				jc.prgrame_Join(j_Name, j_Index, j_Phone, j_Id, j_Pwd, j_Ads, j_Mail);
			}
		});
		j_Btn_No.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				login_join_View.dispose();
			}
		});
	}

	public void login_find() {
		// ID i
		// Pwd p
		// 아이디 찾기
		// 비밀번호 찾기
		Image icon = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB_PRE);
		JDialog login_find_View = wg.JDialogAdd(300, 300, 515, 530);
		JPanel background = wg.JPanelAdd(0, 0, 500, 500);
		JLabel background_P = new JLabel(wg.ImageIcon("./img/find_Background.png"));
		JTextField i_Input_Id = new JTextField();
		JTextField i_Input_Number = new JTextField();
		MyCustomJButton i_Btn_ok = new MyCustomJButton();

		JTextField p_Input_Id = new JTextField();
		JTextField p_Input_Number = new JTextField();
		JTextField p_Input_Mail = new JTextField();
		MyCustomJButton p_Btn_ok = new MyCustomJButton();
		login_find_View.setIconImage(icon);
		i_Btn_ok.setBounds(360, 207, 65, 60);
		i_Btn_ok.setText("확 인");
		i_Btn_ok.setBackground(Color.white);
		background.add(i_Btn_ok);

		p_Btn_ok.setBounds(360, 347, 65, 60);
		p_Btn_ok.setText("확 인");
		p_Btn_ok.setBackground(Color.white);
		background.add(p_Btn_ok);

		i_Input_Id.setBounds(150, 207, 200, 20);
		i_Input_Number.setBounds(150, 237, 200, 20);
		background_P.setBounds(0, 0, 500, 500);
		background.add(background_P);

		p_Input_Id.setBounds(150, 337, 200, 20);
		p_Input_Number.setBounds(150, 367, 200, 20);
		p_Input_Mail.setBounds(150, 397, 200, 20);

		background.add(i_Input_Number);
		background.add(i_Input_Id);

		background.add(p_Input_Id);
		background.add(p_Input_Number);
		background.add(p_Input_Mail);

		login_find_View.add(background);

		login_find_View.setVisible(true);

		i_Btn_ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String i_Id = i_Input_Id.getText();
				String i_Index = i_Input_Number.getText();
				jc.id_Find(i_Id,i_Index);
				
			}
		});
		p_Btn_ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String p_Id = p_Input_Id.getText();
				String p_Index = p_Input_Number.getText();
				String p_mail = p_Input_Mail.getText();
				jc.pwd_Find(p_Id, p_Index,p_mail);
			}

		});
	}
}