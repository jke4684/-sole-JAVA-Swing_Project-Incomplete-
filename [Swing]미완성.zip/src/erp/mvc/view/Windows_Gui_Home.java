package erp.mvc.view;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class Windows_Gui_Home {
	public JDialog JDialogAdd(int x, int y, int width, int height) {
		JDialog jdialogadd = new JDialog();
		jdialogadd.dispose();
		jdialogadd.setBounds(x, y, width, height);
		jdialogadd.getContentPane().setBackground(Color.white);
		return jdialogadd;
	}
	
	public JPanel JPanelAdd(int x, int y, int width, int height) {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(x, y, width, height);
		panel.setBackground(Color.white);		
		return panel;
	}
	
	public JRootPane JRootPaneAdd(int x, int y, int width, int height) {
		JRootPane panel = new JRootPane();
		panel.setLayout(null);
		panel.setBounds(x, y, width, height);
		panel.setBackground(Color.white);
		return panel;
	}

	public JLayeredPane JLayeredPaneAdd(int x, int y, int width, int height) {
		JLayeredPane panel = new JLayeredPane();
		panel.setLayout(null);
		panel.setBounds(x, y, width, height);
		panel.setBackground(Color.white);
		return panel;
	}

	public ImageIcon ImageIcon(String path) {
		ImageIcon icon = new ImageIcon(path);
		return icon;
	}
	
	
//	--------------------------------------------------------------
	public JPanel home_View() {
		JPanel home_View = JPanelAdd(302, 217, 1190, 579);
		home_View.setBackground(new Color(0, 0, 0, 0));
		
		return home_View;
	}
	public JLabel home_View_Image(String path) {
		JLabel home_Resume = new JLabel(ImageIcon(path));
		home_Resume.setBounds(0, 0, 1190, 580);
		return home_Resume;
	}
	

	
}
