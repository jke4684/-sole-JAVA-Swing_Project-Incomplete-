package erp.mvc.view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import erp.mvc.controller.MyCustomJButton;

public class Main_Product_init {
	private Windows_Gui_Home wg = new Windows_Gui_Home();
	JLabel product;
	JFrame view = new JFrame();

//0,0,1500,800
//	@SuppressWarnings("unused")
	public Main_Product_init() {
		new MyCustomJButton();
		view.setResizable(false);
//		view.setUndecorated(true);
		//최대화 최소화 비활성화 
		view.setLayout(null);
		view.setSize(1500, 800);
		view.setLocation(150, 150);
		view.setVisible(true);
		view.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

//		mlv.login_View();
		view.repaint();
		Product_View();
	}
	
	
	public void Product_View() {
		JPanel product_View = wg.JPanelAdd(-10, 0, 1500, 800);
	
		
		product = new JLabel(wg.ImageIcon("./img/Main_Product_View.jpg"));
		product.setBounds(0, 0, 1500, 800);
		product_View.add(product);
		
		

		view.add(product_View);
		new Main_Product_Top(view,product);
		new Main_Product_Left(view,product);
		new Main_Product_Home(view,product);
		view.repaint();

	}
}
