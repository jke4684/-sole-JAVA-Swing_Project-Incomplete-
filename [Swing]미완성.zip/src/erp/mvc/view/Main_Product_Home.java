package erp.mvc.view;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Main_Product_Home { 
	public Main_Product_Home(JFrame view, JLabel product){
		
	}
	//초기 셋팅 값 받아야한다. 
	private Windows_Gui_Home wg = new Windows_Gui_Home();
	
	
	
}
