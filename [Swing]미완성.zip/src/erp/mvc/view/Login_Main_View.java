package erp.mvc.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPasswordField;
import javax.swing.JRootPane;
import javax.swing.JTextField;

import erp.mvc.controller.Join_controller;
import erp.mvc.controller.MyCustomJButton;

@SuppressWarnings("serial")
public class Login_Main_View extends JFrame {
//	Toolkit kit = Toolkit.getDefaultToolkit();
	// Image img = kit.getImage(������ ���);
//	setIconImage(img);
	private Windows_Gui_Home wg = new Windows_Gui_Home();
	private JRootPane rootPane = wg.JRootPaneAdd(0, 0, 1500, 800);

	private JLabel main_Scroll_L = new JLabel(wg.ImageIcon("./img/main_scrollrber.png"));

	private MyCustomJButton btn__Scroll_Min = new MyCustomJButton(wg.ImageIcon("./img/top_scrollber_28_20_min.png"));
	private MyCustomJButton btn_Scroll_Exit = new MyCustomJButton(wg.ImageIcon("./img/top_scrollber_28_20_exit.png"));
	private JLayeredPane login_BGPanel = wg.JLayeredPaneAdd(0, 15, 1150, 785);
	private JLayeredPane login_Panel = wg.JLayeredPaneAdd(1150, 15, 350, 785);
	
//	폰트 설정 // Font font = new Font("맑은고딕",Font.BOLD,24);
	private JLabel background = new JLabel(wg.ImageIcon("./img/Login_Background.jpg"));
	private JLabel login_view = new JLabel(wg.ImageIcon("./img/Login_panel.jpg"));
	private MyCustomJButton btnLogin = new MyCustomJButton(wg.ImageIcon("./img/Login_btnImage.png"));
	private MyCustomJButton btnLogin_join = new MyCustomJButton(wg.ImageIcon("./img/jogin_87_36_join.png"));
	private MyCustomJButton btnLogin_find = new MyCustomJButton(wg.ImageIcon("./img/jogin_139_36_find.png"));
	private JTextField login_id = new JTextField("아이디를 입력해주세요.");
	private JPasswordField login_password = new JPasswordField("비밀번호를 입력해주세요.");
	
	public Login_Main_View() {
		new MyCustomJButton();
		this.setLayout(null);
		this.setSize(1500, 800);
		this.setLocation(150, 150);
		this.setUndecorated(true);// 화면 테두리 제거
		this.setVisible(true);
		this.add(rootPane);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

//		mlv.login_View();
		login_View();
		top_Scrollber(0, 0, 1500, 30);
		this.repaint();

	}

	public void top_Scrollber(int x, int y, int wdith, int height) {

		JLayeredPane top_scollorber = wg.JLayeredPaneAdd(x, y, wdith, height);
		top_scollorber.setLayout(null);

		main_Scroll_L.setBounds(0, 0, wdith, height);

		btn__Scroll_Min.setBounds(wdith-65, 5, 28, 20);
		btn__Scroll_Min.setBorderPainted(false);
		top_scollorber.add(btn__Scroll_Min);

		btn_Scroll_Exit.setBounds(wdith-35, 5, 28, 20);
		btn_Scroll_Exit.setBorderPainted(false);
		top_scollorber.add(btn_Scroll_Exit);
		top_scollorber.add(main_Scroll_L);
		rootPane.add(top_scollorber);

		btn_Scroll_Exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		main_Scroll_L.addMouseMotionListener(new frameMouseEvent());
		btn__Scroll_Min.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setState(JFrame.ICONIFIED);
			}
		});
	}

	class frameMouseEvent implements MouseMotionListener {
		// 해당 컴포넌트위에서 마우스가 눌러진 상태로 드래그 될때 발생

		public void mouseDragged(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			setLocation(e.getLocationOnScreen().x - 10, e.getLocationOnScreen().y - 10);
		}

		// http://egloos.zum.com/tobby48/v/2723865
		// 당연히 MouseMotionAdapter로 구현됨.
		@Override
		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub

		}
	}
	public void login_View() {
		// 로그인 버튼 클릭 시 아이디 필드, 비밀번호 필드 - 회원 테이블 비교
		// 라벨 클릭 시 이동 수정.
		
		// 로그인 배경화면
		login_id.setBounds(20, 260, 220, 45);
		login_view.add(login_id);

		login_password.setBounds(20, 320, 220, 45);
		login_view.add(login_password);

		btnLogin_find.setBounds(18, 380, 139, 36);
		btnLogin_find.setBorderPainted(false);
		login_Panel.add(btnLogin_find);

//		오른쪽 정렬 텍스트 // labelfind.setHorizontalAlignment(SwingConstants.RIGHT);
		btnLogin_join.setBounds(170, 380, 87, 36);
		btnLogin_join.setBorderPainted(false);
		login_Panel.add(btnLogin_join);

		btnLogin.setBounds(245, 260, 97, 98);
		btnLogin.setBorderPainted(false);
		login_Panel.add(btnLogin);

		background.setBounds(0, 0, 1150, 800);
		login_BGPanel.add(background);
		rootPane.add(login_BGPanel);

		// 로그인 패널
		login_view.setBounds(0, 0, 350, 800);
		login_Panel.add(login_view);
		rootPane.add(login_Panel);
		
		btnLogin.addActionListener(new ActionListener() {
// 로그인 이벤트 
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				rootPane.remove(login_BGPanel);
//				rootPane.remove(login_Panel);
				String id = login_id.getText();
				String pwd = login_password.getText();
				new Join_controller().id_Login(id,pwd);
				dispose();
				new Main_Product_init();
				rootPane.repaint();
				
			}
			
		});
		btnLogin_find.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Login_Main_Evt().login_find();
			}
		});
		btnLogin_join.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Login_Main_Evt().login_join();
			}
		});
		login_id.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				login_id.setText("");
			}
		});
		login_password.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				login_password.setText("");
			}
		});
//		this.revalidate();
//		login_Panel.repaint();//새로고침

	}

	

}
