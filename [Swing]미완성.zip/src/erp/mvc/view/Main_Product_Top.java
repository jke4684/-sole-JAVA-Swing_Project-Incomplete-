package erp.mvc.view;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import erp.mvc.controller.MyCustomJButton;

public class Main_Product_Top {
	private Windows_Gui_Home wg = new Windows_Gui_Home();
	private int x;
	private int y;
	private JPanel product_Top = wg.JPanelAdd(0, 0, 1500, 217);
	
	private MyCustomJButton t_Resume_Revise = new MyCustomJButton(wg.ImageIcon("./img/Resume_Revise.png"));
	private MyCustomJButton t_S_Add = new MyCustomJButton(wg.ImageIcon("./img/S_Add.png"));
	private MyCustomJButton t_S_Revise = new MyCustomJButton(wg.ImageIcon("./img/S_Revise.png"));
	private MyCustomJButton t_P_Add = new MyCustomJButton(wg.ImageIcon("./img/P_Add.png"));
	private MyCustomJButton t_P_Revise = new MyCustomJButton(wg.ImageIcon("./img/P_Revise.png"));
	private MyCustomJButton t_Delete = new MyCustomJButton(wg.ImageIcon("./img/Delete.png"));
	private MyCustomJButton t_Logout = new MyCustomJButton(wg.ImageIcon("./img/Logout.png"));
	
	private JDialog t_S_JDialog = new JDialog();
	private JLabel one_Lable = new JLabel();
	private JTextField one_Text = new JTextField();
	private JLabel two_Lable = new JLabel();
	private JTextField two_Text = new JTextField();
	private JLabel three_Lable = new JLabel();
	private JTextField three_Text = new JTextField();
	private MyCustomJButton s_T_Ok = new MyCustomJButton();
	private MyCustomJButton s_T_No = new MyCustomJButton();
	private JLabel p_One_Lable = new JLabel();
	private JTextField p_One_Text = new JTextField();
	private JLabel p_Two_Lable = new JLabel();
	private JTextField p_Two_Text = new JTextField();
	private JLabel p_Three_Lable = new JLabel();
	private JTextField p_Three_Text = new JTextField();
	private MyCustomJButton p_T_Ok = new MyCustomJButton();
	private MyCustomJButton p_T_No = new MyCustomJButton();
	private JDialog image_Read_Frame = new JDialog();
	private JTextField image_Read_Date = new JTextField();
	private MyCustomJButton image_Read = new MyCustomJButton();
	private JLabel info = new JLabel();
	@SuppressWarnings("serial")
	private JTextField t_Internet = new JTextField() {
		public void setBorder(Border border) {
		}
	};
	

	public  Main_Product_Top(JFrame view, JLabel product) {
		new MyCustomJButton();
		t_Logout.setBounds(1431, 0, 69, 39);
		t_Logout.setBorderPainted(false); // 외곽선제거
//		t_Logout.setContentAreaFilled(false); // 내용 영역 X 
		t_Logout.setFocusPainted(false); // 테두리 미사용
		t_Resume_Revise.setBounds(447, 120, 75, 70);

		t_S_Add.setBounds(562, 120, 75, 70);

		t_S_Revise.setBounds(677, 120, 75, 70);

		t_P_Add.setBounds(792, 120, 75, 70);
		t_P_Revise.setBounds(907, 120, 75, 70);

		t_Delete.setBounds(1022, 120, 75, 70);

		// JtextField
		t_Internet.setText("Google 검색할 내용을 입력해주세요.(띄어쓰기 X)");
		t_Internet.setBounds(473, 60, 600, 35);

		product_Top.setLayout(null);
		product_Top.setBackground(new Color(0, 0, 0, 0));

		product_Top.add(t_Logout);
		product_Top.add(t_Resume_Revise);
		product_Top.add(t_S_Add);
		product_Top.add(t_S_Revise);
		product_Top.add(t_P_Add);
		product_Top.add(t_P_Revise);
		product_Top.add(t_Delete);
		product_Top.add(t_Internet);
		product.add(product_Top);
		t_Logout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				view.dispose();
				new Login_Main_View();
			}
		});
		t_Resume_Revise.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e2) {// 로그인 할때
				// 파일 입출력은 처음 시작할 때 한번하고 버튼 누르면 데이터를 참조하게 로그인에서 안된다.
				image_Raed();

			}
		});

		t_S_Add.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e3) {
				t_S_Frame();
			}
		});
		t_S_Revise.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e3) {
				t_S_Frame();
			}
		});
		t_Internet.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				t_Internet.setText("");
			}
		});
		t_P_Add.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JPanel t_P_Add_Frame = wg.home_View();
				t_P_Add_Re(t_P_Add_Frame,view,product);
			}
		});
		t_P_Revise.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				JPanel t_P_Revise_Frame = wg.home_View();
				t_P_Add_Re(t_P_Revise_Frame,view,product);
			}
		});
		class key implements KeyListener {

			public void keyPressed(KeyEvent e) {

				Point p = getLocation();

				if (e.getKeyCode() == 10) {
					try {
						String data = t_Internet.getText();
						Desktop.getDesktop()
								.browse(new URI("https://www.google.com/search?source=hp&ei=469HXdudA47Z-Qa-2YHICQ&q="
										+ data
										+ "&oq=&gs_l=psy-ab.3.0.35i39l10.0.0..1806...1.0..0.179.179.0j1......0......gws-wiz.....10.QploFlM3YJU"));
					} catch (IOException e1) {
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						e1.printStackTrace();
					} finally {

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

		}
		t_Internet.addKeyListener(new key());
		
	}

	public void t_S_Frame() {
		t_S_JDialog.setLayout(null);
		t_S_JDialog.setBounds(300, 300, 900, 550);
		t_S_JDialog.getContentPane().setBackground(Color.white);

		s_T_Ok.setBounds(680, 460, 70, 30);
		s_T_Ok.setText("OK");

		s_T_No.setBounds(770, 460, 70, 30);
		s_T_No.setText("No");

		one_Lable.setBounds(43, 17, 800, 30);
		one_Lable.setBackground(Color.white);
		one_Lable.setText("교육기관 명");

		one_Text.setBounds(43, 50, 800, 30);

		two_Lable.setText("과  정  명");
		two_Lable.setBounds(43, 80, 800, 30);
		two_Lable.setBackground(Color.white);

		two_Text.setBounds(43, 120, 800, 30);

		three_Lable.setText("교  육  내  용");
		three_Lable.setBounds(43, 160, 800, 30);
		three_Lable.setBackground(Color.white);

		three_Text.setBounds(43, 200, 800, 250);

		t_S_JDialog.add(one_Lable);
		t_S_JDialog.add(one_Text);
		t_S_JDialog.add(one_Text);
		t_S_JDialog.add(two_Lable);
		t_S_JDialog.add(two_Text);
		t_S_JDialog.add(three_Lable);
		t_S_JDialog.add(three_Text);
		t_S_JDialog.add(s_T_No);
		t_S_JDialog.add(s_T_Ok);
		t_S_JDialog.setVisible(true);
	}

	public void t_P_Add_Re(JPanel product_Home_View,JFrame view, JLabel product) {
		p_T_Ok.setBounds(680, 460, 70, 30);
		p_T_Ok.setText("OK");

		p_T_No.setBounds(770, 460, 70, 30);
		p_T_No.setText("No");

		p_One_Lable.setBounds(43, 17, 800, 30);
		p_One_Lable.setBackground(Color.white);
		p_One_Lable.setText("프로젝트명");

		p_One_Text.setBounds(43, 50, 800, 30);

		p_Two_Lable.setText("이  미  지");
		p_Two_Lable.setBounds(43, 80, 800, 30);
		p_Two_Lable.setBackground(Color.white);

		p_Two_Text.setBounds(43, 120, 800, 30);

		p_Three_Lable.setText("교  육  내  용");
		p_Three_Lable.setBounds(43, 160, 800, 30);
		p_Three_Lable.setBackground(Color.white);

		p_Three_Text.setBounds(43, 200, 800, 250);

		product_Home_View.add(p_One_Lable);
		product_Home_View.add(p_One_Text);
		product_Home_View.add(p_One_Text);
		product_Home_View.add(p_Two_Lable);
		product_Home_View.add(p_Two_Text);
		product_Home_View.add(p_Three_Lable);
		product_Home_View.add(p_Three_Text);
		product_Home_View.add(p_T_No);
		product_Home_View.add(p_T_Ok);
		product_Home_View.setVisible(true);
		product_Home_View.repaint();
		product.add(product_Home_View);
		view.repaint();
	}

	public void image_Raed() {
		
		image_Read_Frame.setLayout(null);
		image_Read_Frame.setBounds(300, 300, 400, 100);
		image_Read_Frame.getContentPane().setBackground(Color.white);

		image_Read_Date.setBounds(10, 10, 280, 30);
		image_Read_Frame.add(image_Read_Date);
		image_Read.setText("업로드");
		image_Read.setBounds(295, 10, 80, 30);
		image_Read_Frame.add(image_Read);
		image_Read_Frame.setVisible(true);
		info.setText("1100*500 px , image를 업로드 해주시기 바랍니다.");
		info.setBounds(10, 35, 400, 30);
		image_Read_Frame.add(info);
		image_Read.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				JFileChooser fileChooser = new JFileChooser();
				int returnValue = fileChooser.showOpenDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					Object filestr = new String();
					filestr = fileChooser.getSelectedFile();
					image_Read_Date.setText((String) filestr.toString());
				}
			}
		});
	}
	// 192.168.43.213

	public Point getLocation() {
		return location();
	}

	@Deprecated
	public Point location() {
		return location_NoClientCode();
	}

	private Point location_NoClientCode() {
		return new Point(x, y);
	}
}
