package erp.mvc.controller;

import java.awt.event.*;

import javax.swing.*;

import javax.swing.tree.*;

 

class JTreeDemo extends JFrame

 

{

	public static void main(String[] args) 

{

	  new JTreeDemo().setVisible(true);

	  }

 private JTree jTree = null;

 private JPanel jp = new JPanel();

 private JButton addB = new JButton("추가");

 private JButton removeB = new JButton("삭제");

 private JButton updateB = new JButton("변경");

 private JButton checkdelB = new JButton("검색해서지우기");

 private DefaultTreeModel model = null;

 

 DefaultMutableTreeNode root = null;

 DefaultMutableTreeNode list = null;

 DefaultMutableTreeNode list2 = null;

 

 {

  jp.add(addB);

  jp.add(removeB);

  jp.add(updateB);

  jp.add(checkdelB);

 }

 

 public JTreeDemo() {

  setDefaultCloseOperation(EXIT_ON_CLOSE);

  

  this.root = new DefaultMutableTreeNode("root");

  this.list = new DefaultMutableTreeNode("하위1");

  this.list2 = new DefaultMutableTreeNode("하위2");

 

  root.add(list);

  root.add(list2);

  jTree = new JTree(root);

  model = (DefaultTreeModel)jTree.getModel();

  

  this.add("Center", new JScrollPane(jTree));

  this.add("South", jp);

  

  /**선택할 하위노드(하위1,하위2)를 클릭하고 추가버튼을 눌러야 한다.**/

  this.addB.addActionListener(

   new ActionListener(){

    public void actionPerformed(ActionEvent e){

     if (getNodeLevel() == 1)

     {

      String newName = JOptionPane.showInputDialog(null,"추가할 이름을 적어주세요.");

      if (newName != null)

      {

       model.insertNodeInto(new DefaultMutableTreeNode(newName), getSelectedNode(), model.getChildCount(getSelectedNode()));
       // 목차 추가부분
      }

     }

    }

  }

  );

  

  /**오직 리프노드만 삭제할 수 있다**/

  this.removeB.addActionListener(

   new ActionListener(){

    public void actionPerformed(ActionEvent e){

     if (getNodeLevel() == 2)

     {

      removeSelectedNode();
      //목차 삭제 부분
     }

    }

  }

  );

 

  /**오직 리프노드만 변경할 수 있다.**/

  this.updateB.addActionListener(

   new ActionListener(){

    public void actionPerformed(ActionEvent e){

     if (getNodeLevel() == 2)

     {

      String newName = JOptionPane.showInputDialog(null, "변경할 이름을 적어주세요.");

      if (newName != null)

      {

       changeNode(newName);
       //변경
      }

      

     }

    }

  }

  );

 

  this.checkdelB.addActionListener(

   new ActionListener(){

    public void actionPerformed(ActionEvent e){

     String checkName = JOptionPane.showInputDialog(null, "검색해서 삭제할 이름을 적어주세요.");

     int count = model.getChildCount(list);

     int count2 = model.getChildCount(list2);

     

     for (int i=0; i<count; i++)

     {

      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)model.getChild(list, i);

      if (checkName.equals(temp.toString()))

      {

       model.removeNodeFromParent(temp);

       return;

       

      }

     }

 

     for (int i=0; i<count2; i++)

     {

      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)model.getChild(list2, i);

      if (checkName.equals(temp.toString()))

      {

       model.removeNodeFromParent(temp);

       return;

      }

     }

    }

  }

  );

 

  jTree.setRootVisible(false);

  this.pack();

 }

 

 

 

 /**선택된 노드의 오브젝트를 얻는 메소드**/

 private DefaultMutableTreeNode getSelectedNode() {

  /*첫번째 방법

  TreePath path = jTree.getSelectionPath();

  if (path == null)

  {

   return null;

  }

  return (DefaultMutableTreeNode)path.getLastPathComponent();

  */

 

  /*두번째 방법*/

  return (DefaultMutableTreeNode)jTree.getLastSelectedPathComponent();

 }

 

 /**선택한 노드를 삭제하는 메소드**/

 private void removeSelectedNode() {

  DefaultMutableTreeNode selectedNode = this.getSelectedNode();

  if (selectedNode != null)

  {

   this.model.removeNodeFromParent(selectedNode);

  }

 }

 

 /**선택한 노드를 새로운 노드로 바꾸는 메소드**/

 private void changeNode(String newName) {

  this.getSelectedNode().setUserObject(newName);

  model.nodeChanged(this.getSelectedNode()); //이상하게 루트노드를 넣어주면 글자표시가 다 안된다...

 }

 

 /**루트부터 선택한 노드의 패스길이를 돌려주는 메소드**/

 private int getNodeLevel() {

  if (this.getSelectedNode() == null)

  {

   return 0;

  }

  return this.getSelectedNode().getLevel();

  

 }

 

 }