package erp.mvc.controller;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import erp.mvc.model.vo.User_Join;

public class Join_controller {
	private ArrayList<User_Join> join_List = new ArrayList<User_Join>();
	{
		// String userName, String password, String residentNumber,String
		// phoneNumber,String address
	}

	public int id_Login(String i_input_Id, String i_Input_Pwd) {
		if (i_input_Id.equals("") || i_input_Id.equals("")) {

			return 0;
		} else {
			join_List.add(new User_Join(i_input_Id, i_Input_Pwd));
			return 1;
		}
	}


	public int id_Find(String i_input_Id, String i_Index) {
		int result= i_Indexcheck(i_Index);
		System.out.println(result);
		if (i_input_Id.equals("") || result == 0 ) {
			System.out.println("유효성이 맞지 않습니다.");
			return 0;
		} else {
			join_List.add(new User_Join(i_input_Id, i_Index));
			System.out.println("유효성이 맞습니다.");
			return 1;
		}
	}

	public int pwd_Find(String i_input_Id, String i_Input_Number, String i_Input_Email) {
		join_List.add(new User_Join(i_input_Id, i_Input_Number, i_Input_Email));
		return 1;
	}

	public int prgrame_Join(String j_Name, String j_Index, String j_Phone, String j_Id, String j_Pwd, String j_Ads,
			String j_Mail) {
		// TODO Auto-generated method stub
		if(j_Name.equals("") || j_Index.equals("") || j_Id.equals("") || j_Pwd.equals("") || j_Ads.equals("") ||j_Mail.equals(""))
		{
			System.out.println("데이터 값을 입력해주세요.");
			return 0;
		}
		else {
			System.out.println("데이터 값이 맞습니다.");
			String pwd = sha256(j_Pwd);		
			join_List.add(new User_Join(j_Name, j_Index, j_Phone, j_Id, pwd, j_Ads, j_Mail));
			return 1;
		}
	}
	public int i_Indexcheck(String i_index) {
		int[] checkNum = { 2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5 };

		String ssn = i_index.replace("-", "").trim();
		// System.out.println(ssn);
		// System.out.println((int)'0'); //0 은 아스키 코드 48
		int sum = 0;
		System.out.println(checkNum.length);
		for (int i = 0; i < checkNum.length; i++) {
			
			int tmp = (ssn.charAt(i) - 48) * checkNum[i]; // 주민번호 각자리수를 checkum배열의 각자리수와 곱
			sum += tmp; // 곱한 결과를 sum변수에 누적
			System.out.println(tmp);
		}
		// System.out.println(sum);
		// System.out.println(sum/11);
		// int nmg = sum%11;
		// System.out.println(nmg);
		// if(nmg==0) nmg = nmg +10;

		int pin = 11 - (sum % 11);

		// 계산값이 2자리가 되었을 경우에는
		// 10을 나눈 나머지 값 혹은 10을 빼주면 마지막 자리의 숫자만 남는다.
		if (pin >= 10)
			pin = pin - 10;
		// int pin = (11 - (sum%11))%10; 위 if문을 대신할수있다.

		if ((ssn.charAt(12) - 48) == pin) { // 주민등록번호 마지막 번호와 계산 값이 같은지 검사
			return 1;
			//유효할 경우. 
		} else {
			return 0;
			//유효하지 않을 경우.
		} // if

	}

//SHA256 chage
	public String sha256(String pass) {
		String SHA = "";

		try {

			MessageDigest sh = MessageDigest.getInstance("SHA-256");

			sh.update(pass.getBytes());

			byte byteData[] = sh.digest();

			StringBuffer sb = new StringBuffer();

			for (int i = 0; i < byteData.length; i++) {

				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));

			}

			SHA = sb.toString();

		} catch (NoSuchAlgorithmException e) {

			e.printStackTrace();

			SHA = null;

		}
		return SHA;
	}

}
