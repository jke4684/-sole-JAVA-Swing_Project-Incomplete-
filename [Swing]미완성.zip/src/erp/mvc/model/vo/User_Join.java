package erp.mvc.model.vo;

public class User_Join implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -803622658449056171L;
	private String Name = "";
	private String index_Number ="";
	private String phone_Number ="";
	private String user_Id = "";
	private String user_Password = "";
	private String user_Address = "";
	private String user_Email = "";

	public User_Join() {

	}
	// 첫 로그인 화면 데이터
	public User_Join(String user_Id, String user_Password) {
		this.user_Id = user_Id;
		this.user_Password = user_Password;
	}

	public User_Join(String Name, String index_Number,int i) {
		// ID 찾기
		this.Name = Name;
		this.index_Number = index_Number;
	}

	public User_Join(String user_Id, String index_Number, String user_Email) {
		this.user_Id = user_Id;
		this.index_Number = index_Number;
		this.user_Email = user_Email;
	}

	public User_Join(String Name, String index_Number, String phone_Number, String user_Id, String user_Password,
			String user_Address, String user_Email) {
		this.Name = Name;
		this.index_Number = index_Number;
		this.phone_Number = phone_Number;
		this.user_Id = user_Id;
		this.user_Password = user_Password;
		this.user_Address = user_Address;
		this.user_Email = user_Email;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getIndex_Number() {
		return index_Number;
	}

	public void setIndex_Number(String index_Number) {
		this.index_Number = index_Number;
	}

	public String getPhone_Number() {
		return phone_Number;
	}

	public void setPhone_Number(String phone_Number) {
		this.phone_Number = phone_Number;
	}

	public String getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}

	public String getUser_Password() {
		return user_Password;
	}

	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}

	public String getUser_Address() {
		return user_Address;
	}

	public void setUser_Address(String user_Address) {
		this.user_Address = user_Address;
	}

	public String getUser_Email() {
		return user_Email;
	}

	public void setUser_Email(String user_Email) {
		this.user_Email = user_Email;
	}

	@Override
	public String toString() {
		return "User_Join [Name=" + Name + ", index_Number=" + index_Number + ", phone_Number=" + phone_Number
				+ ", user_Id=" + user_Id + ", user_Password=" + user_Password + ", user_Address=" + user_Address
				+ ", user_Email=" + user_Email + "]";
	}
}
