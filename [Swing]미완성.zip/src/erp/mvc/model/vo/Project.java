package erp.mvc.model.vo;

public class Project implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4322307543194947957L;
	
	private String project_Name = "";
	private String project_Content ="";
	private String project_I_Video = "";
	
	public Project() {
		
	}
	public Project(String project_Name,String project_Content,String project_I_Video) {
		this.project_Name = project_Name;
		this.project_Content =project_Content;
		this.project_I_Video = project_I_Video;
	}
	
	public String getProject_Name() {
		return project_Name;
	}
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}
	public String getProject_Content() {
		return project_Content;
	}
	public void setProject_Content(String project_Content) {
		this.project_Content = project_Content;
	}
	public String getProject_Video() {
		return project_I_Video;
	}
	public void setProject_Video(String project_Video) {
		this.project_I_Video = project_Video;
	}
	@Override
	public String toString() {
		return "Project [project_Name=" + project_Name + ", project_Content=" + project_Content + ", project_Video="
				+ project_I_Video + "]";
	}
}
