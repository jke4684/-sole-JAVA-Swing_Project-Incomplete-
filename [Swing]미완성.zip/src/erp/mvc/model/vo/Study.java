package erp.mvc.model.vo;

public class Study implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4872541671238253226L;
	private String study_Name = "";
	private String study_Content ="";
	private String study_Video = "";

	public Study() {
		
	}

	public Study(String study_Name,String study_Content,String study_Video) {
		this.study_Name=study_Name;
		this.study_Content=study_Content;
		this.study_Video=study_Video;
	}
	
	
	public String getstudy_Name() {
		return study_Name;
	}
	public void setstudy_Name(String study_Name) {
		this.study_Name = study_Name;
	}
	public String getstudy_Content() {
		return study_Content;
	}
	public void setstudy_Content(String study_Content) {
		this.study_Content = study_Content;
	}
	public String getstudy_Video() {
		return study_Video;
	}
	public void setstudy_Video(String study_Video) {
		this.study_Video = study_Video;
	}
	@Override
	public String toString() {
		return "study [study_Name=" + study_Name + ", study_Content=" + study_Content + ", study_Video="
				+ study_Video + "]";
	}
}
