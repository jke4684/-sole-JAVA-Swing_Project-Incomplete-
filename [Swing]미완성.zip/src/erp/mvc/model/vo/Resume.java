package erp.mvc.model.vo;

public class Resume implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3232649965177036384L;
	private String resume_Images_Path = "";

	public Resume() {
		
	}
	public Resume(String resume_Images_Path) {
		this.resume_Images_Path = resume_Images_Path;
	}

	public String getResume_Images_Path() {
		return resume_Images_Path;
	}

	public void setResume_Images_Path(String resume_Images_Path) {
		this.resume_Images_Path = resume_Images_Path;
	}
	@Override
	public String toString() {
		return "Resume [resume_Images_Path=" + resume_Images_Path + "]";
	}
}
