package common;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/*
 * Dao 단 
 * 	1) DB에 접속(연결)
 * 	2) Controller에서 전달받은 데이터를 SQL 구문을 통해 DB에 전송 후 받기 
 * 	   (Select문일 경우 결과 : 조회된 ResultSet / DML문일 경우 결과 : int)
 * 
 * 	3) DML 구문일 경우 트랜잭션 처리 (commit, rollback)
 */
//////////////////////////////////////////////////////////////////

/*
 *	1) JDBC Driver 등록처리  
 *	2) Connection 객체 생성 : 등록된 클래스를 이용하여 DB에 연결하여 생성
 *	3) Statement 객체 생성 : Statement 객체를 통해 실행 및 결과받기
 *	4) 쿼리문 전송 및 실행 결과 받기 : Statement 객체를 통해 실행 및 결과 받기
 *	5) 실행결과 -> Select문 -> ResultSet(조회된 데이터 담김) 
 *				DML문(insert, update, delete)문일 경우 -> int (처리된 행의 개수)
 *	6_1) 실행 결과가 ResultSet일 경우 ResultSet에 있는 데이터를 가지고 vo 객체 생성
 *	6_2) 실행 결과가 int일 경우 트랜잭션 처리(commit, rollback)
 *
 *	7) 위에 생성던 것(jdbc 관련된 객체들)를 반드시 자원 반납!!( 생성된 역순)
 *
 */ 

//Sing
public class JDBCTemplate {
	public static Connection getconnection() {
		Connection conn =null;
		//SQL 문을 전송하고 그에 해당하는 결과를 받는 객체 선언 
		//DB의 연결정보를 담는 객체(JDBC 드라이버와 DB 사이를 연결)
		
		Properties prop = new Properties();
		//DB에 전송할 SQL 구문을 실행하는 객체 뿐만 아니라 결과를 받는 객체 
		
		try {
			prop.load(new FileReader("resources/driver.properties"));
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String password = prop.getProperty("password");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
			conn.setAutoCommit(false);
			//기본 값은 True, 원칙은 application에서 모든 걸 제어하겠다. 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}
}





